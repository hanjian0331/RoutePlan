//
//  Vertex.swift
//  traveling-salesman-problem
//
//  Created by David Nadoba on 09/02/2017.
//  Copyright © 2017 David Nadoba. All rights reserved.
//

import Foundation


/// A vertex descripes a node in a Graph.
protocol Vertex: Hashable {
    
}
